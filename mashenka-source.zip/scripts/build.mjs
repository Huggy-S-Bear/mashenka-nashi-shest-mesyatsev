// Let Vite's native Windows handles finish closing before the CLI exits.
// Keep nonzero exits untouched so build failures still fail immediately.
if (process.platform === 'win32') {
 const exit = process.exit.bind(process);
 process.exit = (code) => {
  if (code === 0) { setTimeout(() => exit(0), 750); return; }
  return exit(code);
 };
}
process.argv = [process.argv[0], 'vinext', 'build'];
await import('../node_modules/vinext/dist/cli.js');

