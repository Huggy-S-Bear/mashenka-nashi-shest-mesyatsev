import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = {
 title:'Машенька, это всё о нас ♡',
 description:'В целой вселенной мы нашли друг друга. Наши первые шесть месяцев.',
 icons:{icon:'/favicon.svg'},
 robots:{index:false,follow:false},
};
export const viewport: Viewport = {width:'device-width',initialScale:1,themeColor:'#fff8f5'};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="ru"><body>{children}</body></html>}
