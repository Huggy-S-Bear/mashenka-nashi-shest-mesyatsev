'use client';
import text from './content.json';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, Heart, LockKeyhole, Sparkles, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogClose } from '@/components/ui/dialog';

const photos = text.photos;

function Album() {
 const rail = useRef<HTMLDivElement>(null);
 const touchX = useRef<number | null>(null);
 const [selected,setSelected] = useState<number | null>(null);
 const [edges,setEdges] = useState({start:true,end:false});
 const move=(step:number)=>setSelected(i=>i===null?null:(i+step+photos.length)%photos.length);
 function updateEdges(){const r=rail.current;if(r)setEdges({start:r.scrollLeft<5,end:r.scrollLeft+r.clientWidth>=r.scrollWidth-5});}
 useEffect(()=>{updateEdges();window.addEventListener('resize',updateEdges);return()=>window.removeEventListener('resize',updateEdges)},[]);
 function scroll(step:number){const r=rail.current;if(r){const item=r.firstElementChild as HTMLElement;r.scrollBy({left:step*((item?.offsetWidth??320)+24),behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})}}
 return <section className="album-section" id="moments">
  <div className="section-heading"><div><p className="eyebrow">{text.album.eyebrow}</p><h2>{text.album.title}</h2><p className="section-note">{text.album.description}</p></div><div className="album-arrows"><Button className="round-button" variant="outline" aria-label="Предыдущие фотографии" disabled={edges.start} onClick={()=>scroll(-1)}><ArrowLeft/></Button><Button className="round-button" variant="outline" aria-label="Следующие фотографии" disabled={edges.end} onClick={()=>scroll(1)}><ArrowRight/></Button></div></div>
  <div className="photo-rail" ref={rail} onScroll={updateEdges} tabIndex={0} aria-label="Фотоальбом. Листай в сторону или используй кнопки со стрелками">
   {photos.map(([file,caption,alt],index)=><button className="album-photo" key={file} onClick={()=>setSelected(index)} aria-label={`Открыть фото ${index+1}: ${alt}`}><img src={`/photos/${file}.webp`} alt={alt} width="600" height="500" loading="lazy"/><span className="photo-caption">{caption}</span><span className="photo-number">{String(index+1).padStart(2,'0')} / {photos.length}</span></button>)}
  </div><p className="album-hint">{text.album.scrollHint}<ArrowRight size={16}/> <span>{text.album.openHint}</span></p>
  <Dialog open={selected!==null} onOpenChange={open=>{if(!open)setSelected(null)}}>
   <DialogContent className="photo-dialog" showCloseButton={false} onKeyDown={e=>{if(e.key==='ArrowLeft'){e.preventDefault();move(-1)}if(e.key==='ArrowRight'){e.preventDefault();move(1)}}}>
    <DialogTitle className="sr-only">Наш фотоальбом</DialogTitle><DialogDescription className="sr-only">Фотографии можно листать стрелками или смахиванием в сторону.</DialogDescription>
    <DialogClose render={<Button variant="ghost" className="dialog-close" aria-label="Закрыть фотографию"/>}><X/></DialogClose>
    {selected!==null&&<><div className="full-photo" onTouchStart={e=>{touchX.current=e.changedTouches[0].clientX}} onTouchEnd={e=>{if(touchX.current!==null){const delta=e.changedTouches[0].clientX-touchX.current;if(Math.abs(delta)>55)move(delta<0?1:-1)}touchX.current=null}}><img src={`/photos/${photos[selected][0]}.webp`} alt={photos[selected][2]}/></div><div className="dialog-caption"><Button className="round-button" variant="outline" aria-label="Предыдущее фото" onClick={()=>move(-1)}><ArrowLeft/></Button><div><p>{photos[selected][1]}</p><span>{selected+1} / {photos.length}</span></div><Button className="round-button" variant="outline" aria-label="Следующее фото" onClick={()=>move(1)}><ArrowRight/></Button></div></>}
   </DialogContent>
  </Dialog>
 </section>
}

function LittleSurprises({onProgress}:{onProgress:(stage:number)=>void}){
 const [hugged,setHugged]=useState(false);
 const [note,setNote]=useState<number | null>(null);
 const [openedNotes,setOpenedNotes]=useState<number[]>([]);
 const [hearts,setHearts]=useState(0);
 const [letters,setLetters]=useState<string[]>([]);
 const [dateChoice,setDateChoice]=useState<number | null>(null);
 const notesUnlocked=hearts===3;
 const puzzleUnlocked=openedNotes.length===text.interactions.notes.length;
 const puzzleDone=letters.join('')===text.interactions.puzzleWord;
 const dateUnlocked=puzzleDone;
 const stage=dateChoice!==null?4:puzzleDone?3:puzzleUnlocked?2:notesUnlocked?1:0;
 useEffect(()=>onProgress(stage),[stage,onProgress]);
 function collectHeart(){setHearts(value=>Math.min(value+1,3));}
 function openNote(index:number){
  if(!notesUnlocked)return;
  setNote(index);
  setOpenedNotes(current=>current.includes(index)?current:[...current,index]);
 }
 function chooseLetter(letter:string){if(!puzzleUnlocked||puzzleDone)return;const next=text.interactions.puzzleLetters[letters.length];if(letter===next)setLetters(current=>[...current,letter]);}
 return <section className="interactive-section" aria-labelledby="surprise-title">
  <div className="interactive-heading"><p className="eyebrow">{text.interactions.eyebrow}</p><h2 id="surprise-title">{text.interactions.title}</h2><p>{text.interactions.description}</p></div>
  <div className="hug-reward"><div className="hug-constellation" aria-hidden="true">{Array.from({length:8},(_,i)=><span key={i} style={{'--i':i} as React.CSSProperties}>♡</span>)}</div><Heart size={28} strokeWidth={1.4}/><p>{hugged?text.interactions.hugReply:text.interactions.hug}</p><Button className="hug-button" onClick={()=>setHugged(true)} aria-pressed={hugged}>{hugged?'Ещё раз ❤️':'Получить объятие'}</Button></div>
  <div className="quest-heading"><Sparkles size={18}/><p>{text.interactions.questEyebrow}</p></div><h3 className="quest-title">{text.interactions.questTitle}</h3><p className="quest-description">{text.interactions.questDescription}</p>
  <div className="quest-progress" aria-label="Прогресс маленького свидания">{[1,2,3,4].map((step,index)=><span key={step} className={stage>=step?'done':''}>{step}{index<3&&<i className={stage>step?'done':''}/>}</span>)}</div>
  <div className="quest-grid">
   <article className={`quest-card catch-card ${notesUnlocked?'complete':''}`}><span className="quest-step">01</span><h3>{text.interactions.stepOne}</h3><p>{text.interactions.stepOneHint}</p><p className="hunt-count" aria-live="polite">{hearts} / 3</p><button className={`collect-heart heart-position-${hearts}`} onClick={collectHeart} disabled={notesUnlocked} aria-label={notesUnlocked?'Все сердечки пойманы':'Поймать сердечко'}><Heart size={46} fill="currentColor"/></button></article>
   <article className={`quest-card notes-card ${notesUnlocked?'unlocked':''}`} aria-disabled={!notesUnlocked}><span className="quest-step">02</span><h3>{text.interactions.stepTwo}</h3><p>{notesUnlocked?text.interactions.stepTwoHint:text.interactions.locked}</p>{!notesUnlocked&&<LockKeyhole className="card-lock" size={23}/>}<div className="note-buttons">{text.interactions.notes.map((_,index)=><button key={index} className={`note-heart ${note===index?'opened':''}`} onClick={()=>openNote(index)} disabled={!notesUnlocked} aria-label={`Открыть сердечко ${index+1}`}><Heart size={28} fill={openedNotes.includes(index)?'currentColor':'none'}/></button>)}</div><p className="note-message" aria-live="polite">{note===null?(notesUnlocked?'Открой все три ❤️':''):text.interactions.notes[note]}</p></article>
   <article className={`quest-card puzzle-card ${puzzleUnlocked?'unlocked':''} ${puzzleDone?'complete':''}`} aria-disabled={!puzzleUnlocked}><span className="quest-step">03</span><h3>{text.interactions.stepThree}</h3><p>{puzzleUnlocked?text.interactions.stepThreeHint:text.interactions.locked}</p>{!puzzleUnlocked&&<LockKeyhole className="card-lock" size={23}/>}<p className="word-slots" aria-live="polite">{text.interactions.puzzleLetters.map((_,index)=><span key={index}>{letters[index]||'♡'}</span>)}</p><div className="letter-buttons">{text.interactions.puzzleLetters.map((letter,index)=><button key={index} onClick={()=>chooseLetter(letter)} disabled={!puzzleUnlocked||index<letters.length} aria-label={`Буква ${letter}`}>{letter}</button>)}</div><p className="puzzle-message">{puzzleDone&&text.interactions.puzzleDone}</p></article>
   <article className={`quest-card date-card ${dateUnlocked?'unlocked':''} ${dateChoice!==null?'complete':''}`} aria-disabled={!dateUnlocked}><span className="quest-step">04</span><h3>{text.interactions.stepFour}</h3><p>{dateUnlocked?text.interactions.stepFourHint:text.interactions.locked}</p>{!dateUnlocked&&<LockKeyhole className="card-lock" size={23}/>}<div className="date-options">{text.interactions.dateOptions.map((option,index)=><button key={option} onClick={()=>setDateChoice(index)} disabled={!dateUnlocked} className={dateChoice===index?'chosen':''}>{option}</button>)}</div><p className="date-message">{dateChoice!==null&&text.interactions.dateReply}</p></article>
  </div>
  {stage>0&&<p className="new-page-note" aria-live="polite">{stage===1?'Открылась следующая страница — наши воспоминания ✨':stage===3?'Открылась следующая страница — наши мечты ✨':stage===4?'Открылась последняя страница — письмо для тебя ✨':''}</p>}
  {stage===4&&<a className="quest-continue" href="#ending"><Sparkles size={17}/>{text.interactions.continue}<ArrowDown size={17}/></a>}
 </section>
}

function LockedStoryBlock({number,title,description}:{number:string,title:string,description:string}){
 return <section className="locked-story"><LockKeyhole size={27}/><p>СТРАНИЦА {number} ПОКА ЗАКРЫТА</p><h2>{title}</h2><span>{description}</span></section>
}

function Surprise(){
 const [open,setOpen]=useState(false);
 return <section className={`ending ${open?'is-open':''}`}>
  <Heart className="ending-heart" size={33} strokeWidth={1}/><p className="eyebrow">{text.ending.eyebrow}</p><h2>{text.ending.title}<br/>{text.ending.titleSecond}</h2><p className="ending-note">{text.ending.description}<br/>{text.ending.descriptionSecond}</p>
  <Button className="pill surprise-button" aria-expanded={open} aria-controls="surprise" onClick={()=>setOpen(!open)}>{open?text.ending.hideButton:text.ending.showButton} <Heart size={17}/></Button>
  <div id="surprise" className="surprise" hidden={!open} aria-live="polite"><div className="floating-hearts" aria-hidden="true">{Array.from({length:9},(_,i)=><span key={i} style={{left:`${7+i*10}%`,animationDelay:`${i*.15}s`}}>♡</span>)}</div><p className="handwritten">{text.ending.greeting}</p><h3>{text.ending.surpriseTitle}<br/>{text.ending.surpriseTitleSecond}</h3><p>{text.ending.congratulations}<br/>{text.ending.love}</p></div>
  <p className="handwritten final-sign">{text.ending.signature}</p>
 </section>
}

export default function Home() {
 const [progress,setProgress]=useState(0);
 return <main>
  <header className="topbar"><a className="wordmark" href="#">ты + я <Heart size={17} /></a><span>{text.header.date}</span><a href="#letter" className="header-link">{text.header.link}</a></header>
  <section className="hero">
   <div className="hero-copy"><p className="eyebrow">{text.hero.eyebrow}</p><h1>{text.hero.title}<br/>{text.hero.titleSecond}<em>{text.hero.titleAccent}</em></h1><p className="hero-note">{text.hero.greeting}<br/>{text.hero.description}</p><a className="pill" href="#letter">{text.hero.letterButton}<ArrowDown size={17}/></a><p className="handwritten hero-sign">{text.hero.signature}</p></div>
   <div className="hero-photos" aria-label="Наши фотографии"><figure className="polaroid hero-photo-main"><img src="/photos/img_9664.webp" width="1350" height="1800" alt="Мы вдвоём на фоне заката" fetchPriority="high"/><figcaption>{text.hero.mainPhotoCaption}</figcaption></figure><figure className="polaroid hero-photo-small"><img src="/photos/img_7898.webp" width="1800" height="1350" alt="Наш поцелуй в парке"/><figcaption>{text.hero.smallPhotoCaption}</figcaption></figure><span className="photo-mark" aria-hidden="true">♡</span></div>
  </section>
  <div className="date-ribbon"><span>{text.dates.start}</span><span className="ribbon-line"/><Heart size={19}/><span className="ribbon-line"/><span>{text.dates.anniversary}</span></div>
  <section id="letter" className="letter-section"><p className="eyebrow">{text.letter.eyebrow}</p><h2>{text.letter.greeting}</h2><div className="letter-body">
   <p>{text.letter.paragraphs[0]}</p>
   <p>{text.letter.paragraphs[1]}</p>
   <p>{text.letter.paragraphs[2]}</p>
   <p>{text.letter.paragraphs[3]}</p>
   <blockquote>{text.letter.quote}<br/><em>{text.letter.quoteAccent}</em></blockquote>
   <p>{text.letter.paragraphs[4]}</p>
   <p>{text.letter.paragraphs[5]}</p>
   <p>{text.letter.paragraphs[6]}</p>
  </div><p className="letter-sign handwritten">{text.letter.signature}</p></section>
  <LittleSurprises onProgress={setProgress}/>
  {progress>=1?<Album/>:<LockedStoryBlock number="01" title="Наши воспоминания" description="Поймай три сердечка, и здесь появится наш фотоальбом."/>}
  {progress>=3?<section id="future" className="future-section"><div className="future-inner"><div className="future-title"><p className="eyebrow">{text.future.eyebrow}</p><h2>{text.future.title}<br/>{text.future.titleSecond}<br/><em>{text.future.titleAccent}</em></h2><p>{text.future.description}</p><img src="/photos/img_9809.webp" alt="Сердечко из наших рук" width="600" height="450" loading="lazy"/></div><div className="dreams">
   <article><span>01</span><div><h3>{text.dreams[0].title}</h3><p>{text.dreams[0].description}</p></div></article>
   <article><span>02</span><div><h3>{text.dreams[1].title}</h3><p>{text.dreams[1].description}</p></div></article>
   <article><span>03</span><div><h3>{text.dreams[2].title}</h3><p>{text.dreams[2].description}</p></div></article>
   <article><span>04</span><div><h3>{text.dreams[3].title}</h3><p>{text.dreams[3].description}</p></div></article>
   <article><span>05</span><div><h3>{text.dreams[4].title}</h3><p>{text.dreams[4].description}</p></div></article>
  </div></div></section>:<LockedStoryBlock number="02" title="Наши мечты" description="Собери слово о нас, чтобы открыть страницу с тем, что у нас впереди."/>}
  {progress>=4?<div id="ending"><Surprise/></div>:<LockedStoryBlock number="03" title="Моё письмо для тебя" description="Выбери наше следующее свидание, и я открою тебе последнюю страницу."/>}
  <footer><a className="wordmark" href="#">ты + я <Heart size={16}/></a><span>{text.footer.text}</span><a href="#" className="back-top">{text.footer.back}</a></footer>
 </main>;
}

