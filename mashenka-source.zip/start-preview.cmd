@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js 22.13 or newer is required. Install Node.js and try again.
 pause
 exit /b 1
)
if not exist node_modules (
 call npm ci
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
echo Open the Local URL printed below. Edit app/content.json and save.
echo Keep this window open. Press Ctrl+C to stop.
call npm run dev
pause
